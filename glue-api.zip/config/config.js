module.exports = {
    AWS_ACCESS_KEY_ID: 'AKIA54QTOHW5JQ5OYWNU',           //process.env.AWS_ACCESS_KEY_ID,
    AWS_SECRET_ACCESS_KEY: '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',       //process.env.AWS_SECRET_ACCESS_KEY,
    AWS_BUCKET_NAME: 'elasticbeanstalk-us-east-1-954597260730'             //process.env.AWS_BUCKET_NAME
  }
